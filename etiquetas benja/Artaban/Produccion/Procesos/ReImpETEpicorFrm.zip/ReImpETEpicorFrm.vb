﻿Imports System.Data.SqlClient 
Public Class ReImpETEpicor
    Dim SQL As String = ""
    Public Tipo As String = ""

    Private Sub ProdProcesoFrm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        CargaCombo(cbOperador, "Select -1 EmpID, '' Name union all select EmpID, Name from Pilot.erp.EmpBasic with(nolock) where EmpStatus = 'A'", "EmpID", "Name")
        CargaCombo(cbOperacion, "Select '-1' OpCode, ''OpDesc union all select OpCode, OpDesc from Pilot.erp.OpMaster with(nolock) where OpType = 'MFG' ", "OpCode", "OpDesc")
        tClic.Enabled = True
    End Sub

    Private Sub CargaCatalogo()
        gCatalogo.DataSource = Nothing
        Dim dsCombos As New DataTable
        Dim daCombos As New SqlDataAdapter
        Dim Producido As String = ""
        If cbPT.Checked = True Then Producido = "1" Else Producido = "0"
        SQL = "exec spRepImpET 'ARTABAN1','" + Tipo + "', '" + Producido + "', '" + eOP.Text + "', '" + eParte.Text + "',"
        If cbOperador.Text = "" Then SQL = SQL + " '', " Else SQL = SQL + "'" + cbOperador.EditValue.ToString + "', "
        SQL = SQL + "'" + eNoEtiqueta.Text + "'"
        Dim CMD As New SqlCommand(SQL, Conexion01)
        If Conexion01.State = False Then Conexion01.Open()
        daCombos.SelectCommand = CMD
        daCombos.Fill(dsCombos)
        gCatalogo.DataSource = dsCombos
    End Sub

    Private Sub CatComposiciones_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        Tab(e)
    End Sub

    Private Sub CatComposiciones_FormClosed(sender As System.Object, e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        FrmMain.Visible = True
    End Sub

    Private Sub bSalir_Click(sender As System.Object, e As System.EventArgs) Handles bSalir.Click
        Me.Close()
    End Sub

    Private Sub tRClic_Tick(sender As System.Object, e As System.EventArgs) Handles tClic.Tick
        bImprimir.Enabled = True
    End Sub

    Private Sub bBuscar_Click(sender As System.Object, e As System.EventArgs) Handles bBuscar.Click
        CargaCatalogo()
    End Sub

    Private Sub bLimpiar_Click(sender As System.Object, e As System.EventArgs) Handles bLimpiar.Click
        eOP.Text = ""
        eParte.Text = ""
        cbOperacion.EditValue = "-1"
        cbOperador.EditValue = -1
        gCatalogo.DataSource = Nothing
    End Sub

    Private Sub bImprimir_Click(sender As System.Object, e As System.EventArgs) Handles bImprimir.Click
        tClic.Enabled = True
        bImprimir.Enabled = False
        'ExportarXLSX(gCatalogo)
        If GridView1.SelectedRowsCount <> 1 Then
            bImprimir.Enabled = True
            tClic.Enabled = False
            Exit Sub
        End If

        Dim seleccionados As Integer() = Me.GridView1.GetSelectedRows
        If seleccionados.Length = 0 Then
            '======Ningun seleccionado======
        Else
            Dim rowsSeleccionados As DataRow
            Dim File = ""
            For Each row As Integer In seleccionados
                rowsSeleccionados = Me.GridView1.GetDataRow(row)
                'MsgBox(rowsSeleccionados(1))
                If Tipo = 8 Then ' Tapizado
                    File = "\\epicor01\Reportes\ArtaReport.exe 1 " + rowsSeleccionados(0).ToString + " " + rowsSeleccionados(1).ToString
                Else
                    File = "\\epicor01\Reportes\ArtaReport.exe 3 " + rowsSeleccionados(0).ToString + " " + rowsSeleccionados(2).ToString + " " + rowsSeleccionados(5).ToString + " " + rowsSeleccionados(7).ToString + " COST " + rowsSeleccionados(1).ToString
                End If
                Shell(File, AppWinStyle.Hide)
            Next
        End If
    End Sub
End Class